<?php
/**
 * Template System
 *
 * A PHP class that allows the complete separation of PHP and HTML
 *
 * @author     Chris Fitzgerald
 * @copyright  Copyright (c) 2010, Chris Fitzgerald
 * @license    http://wiki.envato.com/buying/licenses-buying/codecanyon-regular-and-extended-license-usage-examples/#php_scripts_regular
 * @version    1.5
 */
class template {
	protected $data 		= '';									// Page variables set by vars()
	protected $filename 	= '';									// Template filename
	protected $gzip	  		= true;		 							// True/False: Turns Gzipping on/off
	protected $ext	  		= '.html';	 							// Default '.html'  Extension for template files (must contain '.' before extension)
	protected $cache  		= 'cache/';	 							// Location of cache files (relative to page calling class)
	protected $root	  		= 'template/';  						// Location of template files (relative to page calling class)
	protected $cfolder  	= 'combined/css/';						// Location of combined css files
	protected $jfolder  	= 'combined/js/';						// Location of combined js files
	protected $yuipath		= '../source/yui-compressor/build/';	// Location of the yui compressor .jar file
	protected $yuiversion	= '2.4.6';								// Version of the yui compressor to determine filename (yuicompressor-2.4.6.jar)
	protected $compress		= false;								// True/False: If set to true css and javascript files will be compressed using yui compressor
	protected $css			= '';									// Used to embed css files
	protected $js			= '';									// Used to embed javascript files
	protected $combine  	= '';									// If left blank no combining will occur
	/**
	 * Overwrite default settings
	 *
	 * @param array  Config vars
	 */
	public function __construct($config = array()) {
		// Overwrite default settings
		if (count($config) > 0) {
			foreach ($config as $key => $val) {
				$this->$key = $val;
			}
		}
	}
	/**
	 * Sets up the page to be displayed
	 * 
	 * @param	string  Page title
	 * @param   string  Template filename
	 * @param	mixed	CSS files to be included (either string or array)
	 * @param	mixed	JS files to be included (either string or array)
	 * @return  void
	 */
	public function display($title, $filename, $css = '', $js = '', $combine = '') {
		// Removes html extension from filename
		$this->filename  = str_replace($this->ext, '', $filename);
		// Replace '/' with '.' to get sub-folders
		$filename = str_replace('/', '.', $this->filename);
		$filename = $this->cache . $filename . '.php';
		// Check to see if there's any css or js files to be embedded
		$this->_embed($css, $js, $combine);
		// If cached page has expired we need to recompile it
		if (!$this->check_expiration($this->root . $this->filename . '.html', $filename)) {
			$this->_compile($this->filename);
		}
		// Load the page
		$this->_page_header($title);
		$this->_read_cache();
		$this->_page_footer();
	}
	/**
	 * Assigns php variables to the data array
	 *
	 * @param   array  Variables to be sent to template
	 * @return  void
	 */
	public function vars($vars) {
		foreach ($vars as $key => $val) {
			$this->data['.'][0][$key] = &$vars[$key];
		}
	}
	/**
	 * Assigns looped php variables to the data array
	 *
	 * @param   string  Block title used in template
	 * @param   array   Variables to be sent to template block
	 * @return  void
	 */
	public function loop($loop, $vars) {
		$this->data[$loop][] = &$vars;
	}
	/**
	 * Embeds css and js files into the template's header
	 *
	 * @param	mixed	List of css files either single string or array
	 * @param	mixed	List of js files either single string or array
	 * @return 	void
	 */
	protected function _embed($css = '', $js = '', $combine = '') {
		// Should they be combined?
		if (!empty($combine)) {
			$this->combine = $combine;
			if (!empty($css)) {
				$this->_combine($css, 'css');
			}
			if (!empty($js)) {
				$this->_combine($js, 'js');
			}
		} else {
			if (is_array($css) && !is_null($css)) {
				foreach ($css as $file) {
					$this->css .= '<link href="' . $file . '" rel="stylesheet" type="text/css" />' . "\n";
				}
			} else {
				$this->css = '<link href="' . $css . '" rel="stylesheet" type="text/css" />' . "\n";
			}
			if (is_array($js) && !is_null($js)) {
				foreach ($js as $file) {
					$this->js .= '<script type="text/javascript" src="' . $file . '"></script>'  . "\n";
				}
			} else {
				$this->js .= '<script type="text/javascript" src="' . $js . '"></script>'  . "\n";
			}
		}
	}
	/**
	 * Combines css and js files into a single file
	 *
	 * @param	mixed	List of css or js files either in single string or array
	 * @param	string	Either 'css' or 'js'
	 * @return 	void
	 */
	protected function _combine($files, $type) {
		// Determine save location
		if ($type == 'css') {
			$folder = $this->cfolder;
		} else {
			$folder = $this->jfolder;
		}
		$filename = $folder . $this->combine . (($this->compress) ? '-min' : '') . '.' . $type;
		// No need to go any further if they haven't been updated
		if ($this->check_expiration($files, $filename)) {
			// Setup the tag
			if ($type == 'css') {
				$this->css .= '<link href="' . $filename . '" rel="stylesheet" type="text/css" />' . "\n";
			} else {
				$this->js .= '<script type="text/javascript" src="' . $filename . '"></script>'  . "\n";
			}
			return;
		}
		// Read each file
		$combined_data = '';
		if (is_array($files) && !is_null($files)) {
			foreach ($files as $file) {
				if (file_exists($file)) {
					$combined_data .= file_get_contents($file) . "\n\n";
				}
			}
		} else {
			if (file_exists($files)) {
				$combined_data = file_get_contents($files);
			}
		}
		$this->write_file($filename, $combined_data);
		// Should the file be copressed?
		if ($this->compress) {
			$this->_compress($filename);
		}
		// Setup the tag
		if ($type == 'css') {
			$this->css .= '<link href="' . $filename . '" rel="stylesheet" type="text/css" />' . "\n";
		} else {
			$this->js .= '<script type="text/javascript" src="' . $filename . '"></script>'  . "\n";
		}
	}
	/**
	 * Compresses CSS and Javascript files
	 *
	 * @param	string	CSS or Javascript content to be compressed
	 * @return	bool	Returns true if compression was a success
	 */
	protected function _compress($file) {
		exec('java -jar ' . $this->yuipath . 'yuicompressor-' . $this->yuiversion . '.jar ' . $file . ' -o ' . $file . ' --charset utf-8', $output, $error);
		if ($error == 0) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * Compiles template files with data array
	 *
	 * @param   string  Template filename
	 * @return  void
	 */
	protected function _compile($file) {
		// Check to see if template extension is included in filename, remove if it is
		$file = (strpos($file, $this->ext)) ? str_replace($this->ext, '', $file) : $file;
		// Get content from template file
		$content = trim(@file_get_contents($this->root . $file . $this->ext));
		// Check to see if any other template files are supposed to be loaded
		preg_match_all('#<!-- INCLUDE (.*?) -->#', $content, $matches);
		foreach ($matches[1] as $files) {
			$this->_compile($files);
		}
		// If template file has been modified recompile cache file
		if ($this->check_expiration($this->root . $this->filename . $this->ext, $this->root . $file)) {
			return;
		}
		$search  = array(
			'#<!-- EMBED CSS -->#',
			'#<!-- EMBED JS -->#',
			'#<!-- INCLUDE (.*?) -->#',
			'#<!-- IF ([a-z0-9\-_]+?).([A-Z0-9\-_]+?) -->#',
			'#<!-- IF (.*?) -->#',
			'#<!-- ELSEIF (.*?) -->#',
			'#<!-- ELSE -->#',
			'#<!-- ENDIF -->#',
			'#<!-- LOOP (.*?) -->#',
			'#<!-- LOOPELSE -->#',
			'#<!-- END (.*?) -->#',
			'#\{([a-z0-9\-_]+?).([A-Z0-9\-_]+?)\}#',
			'#\{([a-z0-9\-_]*?)\}#is',
		);
		$replace = array(
			"<?php echo \$this->css; ?>",
			"<?php echo \$this->js; ?>",
			"<?php \$this->_include_file('\\1') ?>",
			"<?php if (!empty(\$item['\\2'])) { ?>",
			"<?php if (!empty(\$this->data['.'][0]['\\1'])) { ?>",
			"<?php } elseif (!empty(\$this->data['.'][0]['\\1'])) { ?>",
			"<?php } else { ?>",
			"<?php } ?>",
			"<?php if (!empty(\$this->data['\\1']) && count(\$this->data['\\1'] > 0)) { foreach (\$this->data['\\1'] as \$item) { ?>",
			"<?php }} else { ?>",
			"<?php } ?>",
			"<?php echo !empty(\$item['\\2']) ? \$item['\\2'] : ''; ?>",
			"<?php echo !empty(\$this->data['.'][0]['\\1']) ? \$this->data['.'][0]['\\1'] : ''; ?>",
		);
		$content = preg_replace($search, $replace, $content);
		$this->_write_cache($file, $content);
	}
	/**
	 * Includes any template file called by template file
	 *
	 * @param   string  Filename of included template file
	 * @return  void
	 */
	protected function _include_file($file) {
		$file = str_replace($this->ext, '', $file);
		$file = str_replace('/', '.', $file);
		include($this->cache . $file . '.php');
	}
	/**
	 * Writes compiled content to cache
	 *
	 * @param   string  Template filename
	 * @param   string  Template content
	 * @return  void
	 */
	protected function _write_cache($file, &$content) {
		// Replace folder slashes to periods
		$filename = $this->cache . str_replace('/', '.', $file) . '.php';
		$this->write_file($filename, $content);
	}
	/**
	 * Loads template file from cache avoiding recompiling
	 *
	 * @return  void
	 */
	protected function _read_cache() {
		// Replace periods with slashes to get sub-folders
		$filename = str_replace('/', '.', $this->filename);
		include($this->cache . $filename . '.php');
	}
	/**
	 * Generates page header
	 *
	 * @param   string  Page title set by display()
	 * @return  void
	 */
	protected function _page_header($title = '') {
		// Gzip if set
		if ($this->gzip) {
			ob_start('ob_gzhandler');
		} else {
			ob_start();
		}
		// Sets the page title
		$this->vars(array(
			'PAGE_TITLE' => $title
		));
	}
	/**
	 * Generates page footer
	 *
	 * @return  void
	 */
	protected function _page_footer() {
		ob_end_flush();
		exit;
	}
	/**
	 * Checks the cache file to see if it's still valid
	 *
	 * @param	mixed	Array or string of original file(s)
	 * @param	string	Filename of cached file
	 * @return	bool	Returns true if cache is still good
	 */
	 protected function check_expiration($original, $cache) {
	 	if (is_array($original)) {
	 		foreach ($original as $file) {
	 			// Do the files even exist?
			 	if (file_exists($file) && file_exists($cache)) {
			 		if (filemtime($cache) < filemtime($file)) {
			 			return false;
			 		}
			 	} else {
			 		return false;
			 	}
	 		}
	 	} else {
	 		// Do the files even exist?
		 	if (file_exists($original) && file_exists($cache)) {
		 		if (filemtime($cache) < filemtime($original)) {
		 			return false;
		 		}
		 	} else {
		 		return false;
		 	}
	 	}
	 	return true;
	 }
	/**
	 * Saves to file
	 *
	 * @param	string	Filename of new file
	 * @param	string	Contents to be added to file
	 * @param	bool	Determines if data is to be appended or overwritten
	 * @return	bool	Returns true if save was sucessful
	 */
	protected function write_file($file, $data, $append = false) {	
		// Make sure the directory exists
		if(!is_dir(dirname($file))){
			mkdir(dirname($file), 0755, true);
		}		
		if ($append) {
			// If file can't be written return false
			if (!file_put_contents($file, $data, FILE_APPEND)) {
				return false;
			}
		} else {
			// If file can't be written return false
			if (!file_put_contents($file, $data)) {
				return false;
			}
		}
		return true;
	}
}